﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBar : MonoBehaviour {

    [SerializeField]
    GameObject m_player;

    RectTransform m_transform;

    float originalLifes;
    float originalHeight;

	// Use this for initialization
	void Start () {
        if (m_player == null)
            m_player = GameObject.FindGameObjectWithTag("Player");
        m_transform = GetComponent<RectTransform>();
        originalLifes = GameState.Instance.Player.Lifes;
        originalHeight = m_transform.sizeDelta.y;
	}
	
	// Update is called once per frame
	void Update () {
        float lifes = m_player.GetComponent<Player>().Lifes;
        float y = (lifes / originalLifes) * originalHeight;
        m_transform.sizeDelta = new Vector2(m_transform.sizeDelta.x, y);
	}
}
